<?php
include_once 'security.php';
include('dbconn.php');
error_reporting(E_ERROR | E_PARSE);
$totalconsSum = 0;
$parentC = $_POST['parentid'];
$clientDisplay = $_POST['resSelected']; //displat all/multiple/name
$contractDisplay = $_POST['resSelectedContracts']; //displat all/multiple/name
$commodity = $rowIER['commodityName'];
$countries = $_POST['resCountriesIER'];
// ($contractDisplay != 'All' && $contractDisplay != 'Multiple') ? $title = 'title = "' . $contractDisplay . '"' : $title = '';

($clientDisplay != 'All' && $clientDisplay != 'Multiple') ? $titleC = 'title = "' . $clientDisplay . '"' : $titleC = '';

$supplierId = $_POST["contractcheckboxIER"];
$year = implode('', $_POST['yearstype']);
$implodeSupplierId = implode(',', $supplierId); // to pass values in IN operator
// echo $implodeSupplierId;
$clients = $_POST['clientcheckboxIER'];
// print_r($clients);
// echo count($clients);
// echo $implode;

$totalconsumtion = [];
$sqlQueryIER = "SELECT * FROM nus_supply_contract 
INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId 
WHERE supplierId IN ($implodeSupplierId)";
// echo $sqlQueryIER;
$resultIER = mysqli_query($conn, $sqlQueryIER);
$rowIER = mysqli_fetch_assoc($resultIER);
if($contractDisplay != 'All' && $contractDisplay != 'Multiple'){
    $contractDisplay = $rowIER['contract_id'];
}

$sqlConsumption = "SELECT totalAnualConsumption FROM nus_supply_contract WHERE supplierId IN ($implodeSupplierId)";
$resultCons = mysqli_query($conn, $sqlConsumption);


while ($rowcons = mysqli_fetch_assoc($resultCons)) {
    $consSum = floatval(str_replace(',', '', $rowcons['totalAnualConsumption']));
    $totalconsSum = $totalconsSum + $consSum;
}
// echo gettype($totalconsSum);
// $intavl[] = intval($totalconsumtion);
// echo gettype($totalconsumtion[0]);
// $totalconsSum = array_sum($totalconsumtion);



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css" />

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<style>
    .chart {
        margin-bottom: 50px;
    }

    ul li {

        width: 25%;

        white-space: nowrap;

        overflow: hidden;

    }



    li h2 {

        margin: 0;

        overflow: hidden;

        text-overflow: ellipsis;

    }



    /* last table css */

    .tableIER,

    .tableIERCommon {

        width: 80%;
        margin-bottom: 50px;
        /* font-size: 12px; */

    }




    .tableIER th,

    .consolidatedTable th,

    .tableIERCommon th {

        background-color: rgba(238, 237, 237, 0.9);

        text-align: left;
        padding: 8px;

    }



    .tableIER .lastHeadIER {

        text-align: right;

    }



    .tableIER tr td {

        text-align: left;
        padding: 8px;

    }



    .tableIERCommon tr td {

        text-align: right;
        padding: 8px;

    }

    #tableIERconsolidated tr td,
    #tableIERclient tr td {
        padding: 8px;
    }

    #tableIERconsolidated tr td:nth-child(1) {
        width: 20%
    }

    #tableIERclient tr td:nth-child(1) {
        width: 20%
    }


    .tableIER tr .lasttdIER {

        text-align: right;

    }



    .headrightAlign {

        text-align: right;

        background-color: red;

    }



    .columGreyTd {

        background-color: rgba(238, 237, 237, 0.9);

        text-align: right;

    }

    .dataTables_length,
    .dataTables_info {
        /* background-color: red; */
        margin: 0 0 0 10%;
        padding: 0 0 1% 0;
    }

    .dataTables_filter,
    .dataTables_paginate {
        margin: 0 10% 0 0;
        padding: 0 0 1% 0;
    }
    .dataTables_wrapper{
        font-size: 0.85rem;
    }

    /* #mytable{
        font-size: 14px;
        background-color: red;
    } */
</style>

<body>
    <!-- <ul>
        <div class="sec1art1Wrapper">
            <img src="img/nus-logo-2020.svg" alt="NUS Logo" width="21%" style="margin: 0 0 20px 10px;">
            <br>
            <li> <span>PARENT NAME</span>
                <h2><?php echo  $rowIER['parentId']; ?></h2>
            </li>
            <li><span>COMMODITY </span>
                <h2><?php echo  ucfirst($rowIER['commodityName']); ?></h2>
            </li>
            <li><span>REPORT PERIOD</span>
                <h2><?php echo  $year; ?></h2>
            </li>
            <li <?php echo $titleC; ?>><span>CLIENTS</span>
                <h2><?php echo $clientDisplay; ?></h2>
            </li>
            <li <?php echo $title; ?>><span>CONTRACTS</span>
                <h2><?php echo  $contractDisplay; ?></h2>
            </li>


            <li><span>REPORT CONSUMPTION (MWH)</span>
                <h2><?php echo number_format($totalconsSum); ?></h2>
            </li>

        </div>
    </ul> -->
</body>


</html>
<?php


$clientarr = $_POST["clientcheckboxIER"];
$clientId = implode(',', $_POST["clientcheckboxIER"]);

$contracts = $_POST["contractcheckboxIER"];

$client_contract1 = array();
$clientName1 = array();
// echo "<pre>";
// print_r($clientarr);
$countclient = count($clientarr);
// echo $countclient;
// echo "Client total = ".count($clientarr);

for ($i = 0; $i < count($clientarr); $i++) {
    array_push($client_contract1, array());
    $sqlQuery1 = "SELECT * FROM nus_supply_contract 
     INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId
    WHERE clientId = $clientarr[$i] AND nus_supply_contract.commodityName = '" . $rowIER['commodityName'] . "'";
    // echo $sqlQuery1."<br>";
    $result1 = mysqli_query($conn, $sqlQuery1);
    while ($row1 = mysqli_fetch_assoc($result1)) {

        if (array_search($row1["supplierId"], $contracts) != "") {
            $clientName1[$i] = $row1["clientcompany"];
            // echo "contractss=".$row1["supplierId"]."<br>";
            $client_contract1[$i][] = $row1["supplierId"];
        }
    }
}
$clientName = array();
$client_contract = array();
$checkNumberOfClients = count($clientName1);



$oo = 0;
foreach ($clientName1 as $value) {
    $clientName[$oo] = $value;
    $oo++;
}

$newContractArrayValue = [];
$flag = 0;
foreach ($client_contract1 as $value) {
    foreach ($value as $value1) {
        array_push($newContractArrayValue, $value1);
        $flag = 1;
    }
    if ($flag == 1) {
        array_push($client_contract, $newContractArrayValue);
        foreach ($newContractArrayValue as $key => $val) {
            unset($newContractArrayValue[$key]);
        }
        $flag = 0;
    }
}

//  echo "<pre>";
//     print_r($clientName);
//     print_r($client_contract);

// if ($_POST["view"] == "Monthly") {

$final_est = array();
$final_hedged = array();
$final_openC = array();
$final_perc_open = array();
$final_perc_hedge = array();
$total_est = 0;
$total_hedge = 0;
$total_open = 0;
$total_perc_hedge = 0;
$total_perc_open = 0;
$total_contract_est = array();
$total_contract_hed = array();
$total_contract_open = array();
$total_contract_perc_hedge = array();
$total_contract_perc_open = array();


for ($k = 0; $k < count($clientName); $k++) {
    // $client_contract[$k] = '';
    //   if($client_contract[$k] != ''){
    $contracts = implode(",", $client_contract[$k]);
    //   }

    // if($client_contract[$k] == ''){
    //     echo "L"."<br>";
    // }



    // contract table

    $contract_consum = array();
    $contract_hedge = array();

    $multy_est = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_hed = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_open = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_perchedge = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $multy_peropen = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);


    if ($contracts == '') {
        $contracts = 0;
    }

    $sqlQuery1 = "SELECT * FROM nus_supply_contract 
 INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId
 WHERE supplierId IN ($contracts) ";

    $result1 = mysqli_query($conn, $sqlQuery1);
    while ($row1 = mysqli_fetch_assoc($result1)) {
        // echo "contracttype-".$row1['contractType'];
        $contract_consum[] = $row1['consumptionmonth'];
        if ($row1["contractType"] == "fixed") {
            $contract_hedge[] = $row1['consumptionmonth'];
        } else {
            $contract_hedge[] = $row1['hedgeconsumption'];
        }
    }





    $consolidated_est = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $consolidated_hed = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $consolidated_open = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $consolidated_perc_hedge = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $consolidated_perc_open = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    $month = array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sep", "Oct", "Nov", "Dec");

    for ($j = 0; $j < count($contract_consum); $j++) {



        $est = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        $hed = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        $openC = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        $perc_hed = array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
        $month_consumtion =  array();
        $month_hedged = array();

        $consumption = explode('|', $contract_consum[$j]);
        $hedged = explode('|', $contract_hedge[$j]);
        // $month = array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "July", "Aug", "Sep", "Oct", "Nov", "Dec");


        for ($i = 0; $i < count($consumption); $i++) {
            $month_consumtion[$i] = explode('-', $consumption[$i]);
            $month_hedged[$i] = explode('-', $hedged[$i]);
        }



        for ($i = 0; $i < count($month_consumtion); $i++) {


            if ($month_consumtion[$i][1] == $year) { //emergency

                $a = array_search($month_consumtion[$i][0], $month);

                $est[$a] = round((float)$est[$a] + (float)$month_consumtion[$i][2],2);
                $hed[$a] = round((float)$hed[$a] + (float)$month_hedged[$i][2],2);

                $multy_est[$a] += (float)$est[$a];
                $multy_hed[$a] += (float)$hed[$a];
            } //emergency


        }


        // for ($kj = 0; $kj < 12; $kj++) {
        //     $multy_est[$kj] += $est[$kj];
        //     $multy_hed[$kj] += $hed[$kj];
        // }
    }

    for ($i = 0; $i < 12; $i++) {
        $multy_open[$i] = round((float)$multy_est[$i] - (float)$multy_hed[$i],2);
        if ($multy_est[$i] == 0) {
            $multy_perchedge[$i] = 0;
        } else {
            $multy_perchedge[$i] = round(((float)$multy_hed[$i] / (float)$multy_est[$i]) * 100,2);
        }
        if ($multy_est[$i] == 0) {
            $multy_peropen[$i] = 0;
        } else {
            $multy_peropen[$i] = round(((float)$multy_open[$i] / (float)$multy_est[$i]) * 100,2);
        }



        $final_est[$k] = $multy_est;
        // print_r($multy_est);
        $final_hedged[$k] = $multy_hed;
        $final_openC[$k] = $multy_open;
        // print_r($final_openC);
        $final_perc_hedge[$k] = $multy_perchedge;
        $final_perc_open[$k] = $multy_peropen;
        $total_contract_est[$k] += (float)$multy_est[$i];
        // echo $total_contract_est[$k];
        $total_contract_hed[$k] += (float)$multy_hed[$i];
        // echo $total_contract_hed[$k];
        $total_contract_open[$k] =  round((float)$total_contract_est[$k] - (float)$total_contract_hed[$k],2);
        //    print_r($total_contract_open);
        //    echo $total_contract_open[$k];


    }
    // if ($total_contract_hed[$k] == 0) {
    //     $total_contract_open[$k] = 0;
    // } else {
    //     $total_contract_open[$k] = (float)$total_contract_est[$k] - (float)$total_contract_hed[$k];
    // }
    if ($total_contract_est[$k] == 0) {
        $total_contract_perc_hedge[$k] = 0;
    } else {
        $total_contract_perc_hedge[$k] = ((float)$total_contract_hed[$k] / (float)$total_contract_est[$k]) * 100;
    }
    if ($total_contract_est[$k] == 0) {
        $total_contract_perc_open[$k] = 0;
    } else {
        $total_contract_perc_open[$k] = ((float)$total_contract_open[$k] / (float)$total_contract_est[$k]) * 100;
    }
}

for ($i = 0; $i <  count($clientName); $i++) {
    for ($j = 0; $j < 12; $j++) {

        $consolidated_est[$j] += (float)$final_est[$i][$j];
        $consolidated_hed[$j] += (float)$final_hedged[$i][$j];
    }
}
// echo "ss<pre>";
// print_r($final_est);
for ($i = 0; $i < 12; $i++) {
    $consolidated_open[$i] = round((float)$consolidated_est[$i] - (float)$consolidated_hed[$i],2);
    if ($consolidated_est[$i] == 0) {
        $consolidated_perc_hedge[$i] = 0;
    } else {
        $consolidated_perc_hedge[$i] = round(((float)$consolidated_hed[$i] / (float)$consolidated_est[$i]) * 100,2);
    }
    if ($consolidated_est[$i] == 0) {
        $consolidated_perc_open[$i] = 0;
    } else {
        $consolidated_perc_open[$i] = round(((float)$consolidated_open[$i] / (float)$consolidated_est[$i]) * 100,2);
    }
    $total_est += round((float)$consolidated_est[$i],2);
    $total_hedge += round((float)$consolidated_hed[$i],2);
    $total_open = round((float)$total_est - (float)$total_hedge,2);
    if ($total_est == 0) {
        $total_perc_hedge = 0;
        $total_perc_open = 0;
    } else {

        $total_perc_hedge = round(((float)$total_hedge / (float)$total_est) * 100,2);
        $total_perc_open = round(($total_open / $total_est) * 100,2);
    }
}

// if ($_POST["view"] == "Monthly") {
?>
<ul>
    <div class="sec1art1Wrapper">
        <img src="img/nus-logo-2020.svg" alt="NUS Logo" width="21%" style="margin: 0 0 20px 10px;">
        <br>
        <li> <span>PARENT NAME</span>
            <h2><?php echo  $rowIER['parentId']; ?></h2>
        </li>
        <li><span>COMMODITY - REPORT PERIOD </span>
            <h2><?php echo  ucfirst($rowIER['commodityName']). ' - ' .$year; ?></h2>
        </li>
        <li><span>REPORT CONTRACT CONSUMPTION (MWH)</span>
            <h2><?php echo number_format($total_est); ?></h2>
        </li>
        <li><span>COUNTRIES</span>
            <h2><?php echo $countries; ?></h2>
        </li>
        <!-- <li><span>REPORT PERIOD</span>
            <h2><?php echo  $year; ?></h2>
        </li> -->
        <li <?php echo $titleC; ?>><span>CLIENTS</span>
            <h2><?php echo $clientDisplay; ?></h2>
        </li>
        <li <?php echo $title; ?>><span>CONTRACTS</span>
            <h2><?php echo  $contractDisplay; ?></h2>
        </li>


        <!-- <li><span>REPORT CONTRACT CONSUMPTION (MWH)</span>
            <h2><?php echo number_format($total_est); ?></h2>
        </li> -->

    </div>
</ul>
<?php

if ($_POST["view"] == "Monthly") {
   
?>
    <section class="chart" id="columnchart_values">

    </section>
    <?php
    //  if($countclient > 1){
    ?>
    <section class="tables">
    <?php
     if($countclient > 1){
    ?>
        <article class="totalTable">
            <table class="tableIERCommon" id="tableIERconsolidated">
                <thead>
                    <th>Consolidated</th>
                    <?php
                    for ($i = 0; $i < count($month); $i++) {
                    ?>
                        <th style="text-align: right;"><?php echo $month[$i] ?></th>
                    <?php
                    }
                    ?>
                    <th style="text-align: right;">Total</th>
                </thead>
                <tbody>

                    <tr>
                        <td>Est. Consumption (MWH)</td>
                        <?php
                        for ($i = 0; $i < 12; $i++) {
                        ?>
                            <td style="text-align: right;"><?php $strvalue = str_replace(",", "", $consolidated_est[$i]);
                                                            $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                            echo preg_replace($regex, ",", number_format((float)$strvalue,2));  ?></td>

                        <?php
                        }
                        ?>
                        <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_est);
                                                echo preg_replace($regex, ",", round((float)$strvalue)); ?></td>
                    </tr>
                    <tr>
                        <td>Hedged Consumption (MWH)</td>
                        <?php
                        for ($i = 0; $i < 12; $i++) {
                        ?>
                            <td><?php $strvalue = str_replace(",", "", $consolidated_hed[$i]);
                                echo  preg_replace($regex, ",", number_format((float)$strvalue,2)); ?></td>

                        <?php
                        }
                        ?>
                        <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_hedge);
                                                echo preg_replace($regex, ",", number_format((float)$strvalue,2));  ?></td>
                    </tr>
                    <tr>
                        <td>Open Consumption (MWH)</td>
                        <?php
                        for ($i = 0; $i < 12; $i++) {
                        ?>
                            <td><?php
                                $strvalue = str_replace(",", "", $consolidated_open[$i]);
                                echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                ?></td>
                        <?php
                        }
                        ?>
                        <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $total_open);
                                                echo  preg_replace($regex, ",", number_format((float)$strvalue,2));  ?></td>
                    </tr>
                    <tr>
                        <td>% Hedged</td>
                        <?php
                        for ($i = 0; $i < 12; $i++) {
                        ?>
                            <td><?php echo number_format((float)$consolidated_perc_hedge[$i], 2) . "%" ?></td>
                        <?php
                        }
                        ?>
                        <td class="columGreyTd"><?php echo number_format((float)$total_perc_hedge, 2) . "%" ?></td>
                    </tr>
                    <tr>
                        <td>% Open</td>
                        <?php
                        for ($i = 0; $i < 12; $i++) {
                        ?>
                            <td><?php echo number_format((float)$consolidated_perc_open[$i], 2) . "%" ?></td>
                        <?php
                        }
                        ?>
                        <td class="columGreyTd"><?php echo number_format((float)$total_perc_open, 2) . "%" ?></td>
                    </tr>

                </tbody>
            </table>
            <!-- number of supply contract -->
        </article>
        <?php
     }
        // echo "contractssss";
        // print_r($clientName);
        $total_client_estimation = array();
        for ($i = 0; $i < count($clientName); $i++) {
            $total_client_estimation[$i] = $total_contract_est[$i];
        }
        arsort($total_client_estimation);
        // echo "<pre>";
        // print_r($total_client_estimation);
        foreach ($total_client_estimation as $key => $value) {
            for ($j = $key; $j == $key; $j++) {
                // echo "Clientname = ".$clientName[$j];
        ?>
                <table class="tableIERCommon" id="tableIERclient">
                    <thead>
                        <th><?php echo $clientName[$j] ?></th>
                        <?php
                        for ($i = 0; $i < count($month); $i++) {
                        ?>
                            <th style="text-align: right;"><?php echo $month[$i] ?></th>
                        <?php
                        }
                        ?>
                        <th style="text-align: right;">Total</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Est. Consumption (MWH)</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>
                                <td class="tdalighRight"><?php
                                                            $strvalue = str_replace(",", "",  $final_est[$j][$i]);
                                                            $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                            echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                                            ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "",  $total_contract_est[$j]);
                                                    echo  preg_replace($regex, ",", round((float)$strvalue)); ?></td>
                        </tr>
                        <tr>
                            <td>Hedged Consumption (MWH)</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>
                                <td class="tdalighRight"><?php
                                                            $strvalue = str_replace(",", "",  $final_hedged[$j][$i]);

                                                            echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                                            ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php
                                                    $strvalue = str_replace(",", "",  $total_contract_hed[$j]);
                                                    echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                                    ?></td>
                        </tr>
                        <tr>
                            <td>Openn Consumption(MWH)</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>
                                <td class="tdalighRight"><?php
                                                            $strvalue = str_replace(",", "",  $final_openC[$j][$i]);

                                                            echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                                            ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php
                                                    //   echo  $total_contract_open[$j];
                                                    $strvalue = str_replace(",", "",  $total_contract_open[$j]);
                                                    echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                                    ?></td>
                        </tr>
                        <tr>
                            <td>% Hedged</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>
                                <td class="tdalighRight"><?php echo number_format((float)$final_perc_hedge[$j][$i], 2) . "%" ?></td>
                            <?php
                            } ?>
                            <td class="columGreyTd"><?php echo number_format((float)$total_contract_perc_hedge[$j], 2) . "%"; ?></td>
                        </tr>
                        <tr>
                            <td>% Open</td>
                            <?php
                            for ($i = 0; $i < 12; $i++) {
                            ?>
                                <td class="tdalighRight"><?php echo number_format((float)$final_perc_open[$j][$i], 2) . "%" ?></td>
                            <?php
                            } ?>
                            <td class="columGreyTd"><?php echo number_format((float)$total_contract_perc_open[$j], 2) . "%" ?></td>
                        </tr>

                    </tbody>
                </table>

        <?php
            }
        }
        ?>

    </section>
<?php
    tableier();
} else {
    // Quarterly calculation

    $final_est_quarter = array();
    $final_hedge_quarter = array();
    $final_open_quarter = array();
    $final_perc_hedge_quarter = array();
    $final_perc_open_quarter = array();
    $final_total_est_quarter = array();
    $final_total_hedge_quarter = array();
    $final_total_open_quarter = array();
    $final_total_perc_hedge_quarter = array();
    $final_total_perc_open_quarter = array();

    $avg_est_quarter = array();
    $avg_hedge_quarter = array();
    $avg_open_quarter = array();
    $avg_perc_hedge_quarter = array();
    $avg_perc_open_quarter = array();
    $avg_total_est_quarter = 0;
    $avg_total_hedge_quarter = 0;
    $avg_total_open_quarter = 0;
    $avg_total_perc_hedge_quarter = 0;
    $avg_total_perc_open_quarter = 0;
    // echo "<pre>";
    // print_r($final_est);
    // echo "<pre>";
    // print_r($final_hedged);

    for ($i = 0; $i < count($clientName); $i++) {
        $q1_est = 0;
        $q2_est = 0;
        $q3_est = 0;
        $q4_est = 0;
        $q1_hedge = 0;
        $q2_hedge = 0;
        $q3_hedge = 0;
        $q4_hedge = 0;

        for ($j = 0; $j < 12; $j++) {
            if ($j < 3) {
                $q1_est += (float)$final_est[$i][$j];
                $q1_hedge += (float)$final_hedged[$i][$j];
            } else if ($j < 6) {
                $q2_est += (float)$final_est[$i][$j];
                $q2_hedge += (float)$final_hedged[$i][$j];
            } else if ($j < 9) {
                $q3_est += (float)$final_est[$i][$j];
                $q3_hedge += (float)$final_hedged[$i][$j];
            } else if ($j < 12) {
                $q4_est += (float)$final_est[$i][$j];
                $q4_hedge += (float)$final_hedged[$i][$j];
            }
        }
        $final_est_quarter[$i][] = $q1_est;
        $final_est_quarter[$i][] = $q2_est;
        $final_est_quarter[$i][] = $q3_est;
        $final_est_quarter[$i][] = $q4_est;

        $final_hedge_quarter[$i][0] = $q1_hedge;
        $final_hedge_quarter[$i][1] = $q2_hedge;
        $final_hedge_quarter[$i][2] = $q3_hedge;
        $final_hedge_quarter[$i][3] = $q4_hedge;

        for ($k = 0; $k < 4; $k++) {
            $final_open_quarter[$i][$k] = (float)$final_est_quarter[$i][$k] - (float)$final_hedge_quarter[$i][$k];

            if ($final_est_quarter[$i][$k] == 0) {
                $final_perc_hedge_quarter[$i][$k] = 0;
            } else {
                $final_perc_hedge_quarter[$i][$k] = (float)($final_hedge_quarter[$i][$k] / (float)$final_est_quarter[$i][$k]) * 100;
            }
            if ($final_est_quarter[$i][$k] == 0) {
                $final_perc_open_quarter[$i][$k] = 0;
            } else {
                $final_perc_open_quarter[$i][$k] = (float)($final_open_quarter[$i][$k] / (float)$final_est_quarter[$i][$k]) * 100;
            }
            // avg calculation
            $avg_est_quarter[$k] += (float)$final_est_quarter[$i][$k];
            $avg_hedge_quarter[$k] += (float)$final_hedge_quarter[$i][$k];
            $avg_open_quarter[$k] = (float)$avg_est_quarter[$k] - (float)$avg_hedge_quarter[$k];
            if ($avg_est_quarter[$k] == 0) {
                $avg_perc_hedge_quarter[$k] = 0;
            } else {
                $avg_perc_hedge_quarter[$k] = ((float)$avg_hedge_quarter[$k] / (float)$avg_est_quarter[$k]) * 100;
            }
            if ($avg_est_quarter[$k] == 0) {
                $avg_perc_open_quarter[$k] = 0;
            } else {
                $avg_perc_open_quarter[$k] = ((float)$avg_open_quarter[$k] / (float)$avg_est_quarter[$k]) * 100;
            }

            // client total values
            $final_total_est_quarter[$i] += (float)$final_est_quarter[$i][$k];
            $final_total_hedge_quarter[$i] += (float)$final_hedge_quarter[$i][$k];
            $final_total_open_quarter[$i] = (float)$final_total_est_quarter[$i] - (float)$final_total_hedge_quarter[$i];
            if ($final_total_est_quarter[$i] == 0) {
                $final_total_perc_hedge_quarter[$i] = 0;
            } else {
                $final_total_perc_hedge_quarter[$i] = ((float)$final_total_hedge_quarter[$i] / (float)$final_total_est_quarter[$i]) * 100;
            }
            if ($final_total_est_quarter[$i] == 0) {
                $final_total_perc_open_quarter[$i] = 0;
            } else {
                $final_total_perc_open_quarter[$i] = ((float)$final_total_open_quarter[$i] / (float)$final_total_est_quarter[$i]) * 100;
            }
        }
    }
    // avg total values
    for ($i = 0; $i < 4; $i++) {
        $avg_total_est_quarter += (float)$avg_est_quarter[$i];
        $avg_total_hedge_quarter += (float)$avg_hedge_quarter[$i];
    }
    $avg_total_open_quarter = (float)$avg_total_est_quarter - (float)$avg_total_hedge_quarter;
    if ($avg_total_est_quarter == 0) {
        $avg_total_perc_hedge_quarter = 0;
    } else {
        $avg_total_perc_hedge_quarter = ((float)$avg_total_hedge_quarter / (float)$avg_total_est_quarter) * 100;
    }
    if ($avg_total_est_quarter == 0) {
        $avg_total_perc_open_quarter = 0;
    } else {
        $avg_total_perc_open_quarter = ((float)$avg_total_open_quarter / (float)$avg_total_est_quarter) * 100;
    }

    // echo "est";
    // echo "<pre>";
    // print_r($final_est_quarter);
    // echo "avg est";
    // echo "<pre>";
    // print_r($avg_est_quarter);
    // echo "hedge";
    // echo "<pre>";
    // print_r($final_hedge_quarter);
    // echo "open";
    // echo "<pre>";
    // print_r($final_open_quarter);
    // echo "perc hedge";
    // echo "<pre>";
    // print_r($final_perc_hedge_quarter);
    // echo "perc open";
    // print_r($final_perc_open_quarter);

?>
    <section class="chart" id="columnchart_values">

    </section>
    <section class="tables">
        <?php
        if($countclient > 1){
        ?>
        <article class="totalTable">
            <table class="tableIERCommon" id="tableIERconsolidated">
                <thead>
                    <th>Consolidated</th>

                    <th style="text-align: right;"><?php echo "Q1" ?></th>
                    <th style="text-align: right;"><?php echo "Q2" ?></th>
                    <th style="text-align: right;"><?php echo "Q3" ?></th>
                    <th style="text-align: right;"><?php echo "Q4" ?></th>

                    <th style="text-align: right;">Total</th>
                </thead>
                <tbody>

                    <tr>
                        <td>Est. Consumption (MWH)</td>
                        <?php
                        for ($i = 0; $i < 4; $i++) {
                        ?>
                            <td style="text-align: right;"><?php $strvalue = str_replace(",", "", $avg_est_quarter[$i]);
                                                            $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                            echo preg_replace($regex, ",", number_format((float)$strvalue,2));  ?></td>

                        <?php
                        }
                        ?>
                        <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $avg_total_est_quarter);
                                                echo preg_replace($regex, ",", round((float)$strvalue)); ?></td>
                    </tr>
                    <tr>
                        <td>Hedged Consumption (MWH)</td>
                        <?php
                        for ($i = 0; $i < 4; $i++) {
                        ?>
                            <td><?php $strvalue = str_replace(",", "", $avg_hedge_quarter[$i]);
                                echo  preg_replace($regex, ",", number_format((float)$strvalue,2)); ?></td>

                        <?php
                        }
                        ?>
                        <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $avg_total_hedge_quarter);
                                                echo preg_replace($regex, ",", number_format((float)$strvalue,2));  ?></td>
                    </tr>
                    <tr>
                        <td>Open Consumption (MWH)</td>
                        <?php
                        for ($i = 0; $i < 4; $i++) {
                        ?>
                            <td><?php
                                $strvalue = str_replace(",", "", $avg_open_quarter[$i]);
                                echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                ?></td>
                        <?php
                        }
                        ?>
                        <td class="columGreyTd"><?php $strvalue = str_replace(",", "", $avg_total_open_quarter);
                                                echo  preg_replace($regex, ",", number_format((float)$strvalue,2));  ?></td>
                    </tr>
                    <tr>
                        <td>% Hedged</td>
                        <?php
                        for ($i = 0; $i < 4; $i++) {
                        ?>
                            <td><?php echo number_format((float)$avg_perc_hedge_quarter[$i], 2) . "%" ?></td>
                        <?php
                        }
                        ?>
                        <td class="columGreyTd"><?php echo number_format((float)$avg_total_perc_hedge_quarter, 2) . "%" ?></td>
                    </tr>
                    <tr>
                        <td>% Open</td>
                        <?php
                        for ($i = 0; $i < 4; $i++) {
                        ?>
                            <td><?php echo number_format((float)$avg_perc_open_quarter[$i], 2) . "%" ?></td>
                        <?php
                        }
                        ?>
                        <td class="columGreyTd"><?php echo number_format((float)$avg_total_perc_open_quarter, 2) . "%" ?></td>
                    </tr>

                </tbody>
            </table>
            <!-- number of supply contract -->
        </article>
        <?php
        }
        // echo "contractssss";
        // print_r($clientName);
        $total_client_estimation = array();
        for ($i = 0; $i < count($clientName); $i++) {
            $total_client_estimation[$i] = $total_contract_est[$i];
        }
        arsort($total_client_estimation);
        // echo "<pre>";
        // print_r($total_client_estimation);
        foreach ($total_client_estimation as $key => $value) {
            for ($j = $key; $j == $key; $j++) {
                // echo "Clientname = ".$clientName[$j];
        ?>
                <table class="tableIERCommon" id="tableIERclient">
                    <thead>
                        <th><?php echo $clientName[$j] ?></th>

                        <th style="text-align: right;"><?php echo "Q1" ?></th>
                        <th style="text-align: right;"><?php echo "Q2" ?></th>
                        <th style="text-align: right;"><?php echo "Q3" ?></th>
                        <th style="text-align: right;"><?php echo "Q4" ?></th>

                        <th style="text-align: right;">Total</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Est. Consumption (MWH)</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>
                                <td class="tdalighRight"><?php
                                                            $strvalue = str_replace(",", "",  $final_est_quarter[$j][$i]);
                                                            $regex = "/\B(?=(\d{3})+(?!\d))/i";
                                                            echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                                            ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php $strvalue = str_replace(",", "",  $final_total_est_quarter[$j]);
                                                    echo  preg_replace($regex, ",", round((float)$strvalue)); ?></td>
                        </tr>
                        <tr>
                            <td>Hedged Consumption (MWH)</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>
                                <td class="tdalighRight"><?php
                                                            $strvalue = str_replace(",", "",  $final_hedge_quarter[$j][$i]);

                                                            echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                                            ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php
                                                    $strvalue = str_replace(",", "",  $final_total_hedge_quarter[$j]);
                                                    echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                                    ?></td>
                        </tr>
                        <tr>
                            <td>Open Consumption (MWH)</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>
                                <td class="tdalighRight"><?php
                                                            $strvalue = str_replace(",", "",  $final_open_quarter[$j][$i]);

                                                            echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                                            ?></td>
                            <?php
                            }
                            ?>
                            <td class="columGreyTd"><?php
                                                    $strvalue = str_replace(",", "",  $final_total_open_quarter[$j]);
                                                    echo  preg_replace($regex, ",", number_format((float)$strvalue,2));
                                                    ?></td>
                        </tr>
                        <tr>
                            <td>% Hedged</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>
                                <td class="tdalighRight"><?php echo number_format((float)$final_perc_hedge_quarter[$j][$i], 2) . "%" ?></td>
                            <?php
                            } ?>
                            <td class="columGreyTd"><?php echo number_format((float)$final_total_perc_hedge_quarter[$j], 2) . "%"; ?></td>
                        </tr>
                        <tr>
                            <td>% Open</td>
                            <?php
                            for ($i = 0; $i < 4; $i++) {
                            ?>
                                <td class="tdalighRight"><?php echo number_format((float)$final_perc_open_quarter[$j][$i], 2) . "%" ?></td>
                            <?php
                            } ?>
                            <td class="columGreyTd"><?php echo number_format((float)$final_total_perc_open_quarter[$j], 2) . "%" ?></td>
                        </tr>

                    </tbody>
                </table>

        <?php
            }
        }
        ?>

    </section>
<?php
    tableier();
}

?>

</div>
<?php
function tableier()
{
?>
    <table class="tableIER" id="myTable" style="width: 80%; font-size:0.85rem;">
        <thead>
            <th>Contracts Included</th>
            <th>Country</th>
            <th>Client</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Supplier</th>
            <th>Contract Type</th>
            <th class="lastHeadIER">Contract Annual Consumption</th>

        </thead>
        <tbody>

            <?php
            include("dbconn.php");
            $contract = implode(",", $_POST["contractcheckboxIER"]);

            $sqlQuery3 = "SELECT * FROM nus_supply_contract                  
             INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId
             WHERE supplierId IN ($contract) ORDER BY nus_supply_contract.contract_id ASC";
            $result3 = mysqli_query($conn, $sqlQuery3);

            while ($row_IERmonthly = mysqli_fetch_assoc($result3)) {
                $sqlValue1[] = $row_IERmonthly;
            }
            for ($i = 0; $i < count($_POST["contractcheckboxIER"]); $i++) {
            ?>
                <tr>
                    <?php

                    ?>

                    <td><?php echo $sqlValue1[$i]['contract_id']; ?></td>
                    <td><?php echo $sqlValue1[$i]['country']; ?></td>
                    <td><?php echo $sqlValue1[$i]['clientcompany']; ?></td>
                    <td><?php $startDate = date_create($sqlValue1[$i]['contractTermfromDate']);
                        echo date_format($startDate, "d-M-Y"); ?></td>
                    <td><?php $endDate = date_create($sqlValue1[$i]['contractTermtoDate']);
                        echo date_format($endDate, "d-M-Y"); ?></td>
                    <td><?php echo $sqlValue1[$i]['supplyName']; ?></td>
                    <td><?php echo ucfirst($sqlValue1[$i]['contractType']); ?></td>
                    <td class="lasttdIER">
                        <?php

                        $totalconsump = str_replace(",", "", $sqlValue1[$i]['totalAnualConsumption']);
                        $regex = "/\B(?=(\d{3})+(?!\d))/i";
                        echo $usdformat = preg_replace($regex, ",", round($totalconsump));
                        ?>
                    </td>

                </tr>
            <?php
            } ?>

        </tbody>
    </table>
<?php
}
$totalestimation = array();
$srvalue = '';
$strclient = '';

for ($i = 0; $i < count($clientName); $i++) {
    $totalestimation[$i] = $total_contract_est[$i];
}
arsort($totalestimation);
// echo "estimation";
// echo "<pre>";
// print_r($totalestimation);

// graph calculation for monthly
if ($_POST["view"] == "Monthly") {
    $k = 0;
    foreach ($totalestimation as $key => $value) {
        // echo $key;
        for ($i = $key; $i == $key; $i++) {

            if ($k < 4) {
                // for ($i = 0; $i < count($clientName); $i++) {
                $strclient .= "," . "'" . $clientName[$i] . "'";
                $total_str .= "," . number_format($total_contract_perc_hedge[$i], 2);
                // echo $total_contract_est[$i]."<br>";
                // $totalestimation[$i] = $total_contract_est[$i];
                $k++;
            }
        }
    }
    // echo $strclient;
    if($countclient > 1){

        $storeAll_IER_Clients = "['','Avg'" . $strclient . "],";
        $storeAll_IER_Total = "['Total'," . number_format($total_perc_hedge, 2) . $total_str . "]";
    }
    else{

        $storeAll_IER_Clients = "[''" . $strclient . "],";
        $storeAll_IER_Total = "['Total'" . $total_str . "]";
    }

    // $storeAll_IER_Clients = "['','Avg'" . $strclient . "],";
    // $storeAll_IER_Total = "['Total'," . number_format($total_perc_hedge, 2) . $total_str . "]";
    // echo $storeAll_IER_Total;
    // echo $storeAll_IER_Clients;
    $storeAll_IER_perc_hedge = '';
    for ($j = 0; $j < 12; $j++) {
        $clientvalue = '';
        $strclient = '';
        $l = 0;
        foreach ($totalestimation as $key => $value) {
            for ($i = $key; $i == $key; $i++) {
                if ($l < 4) {
                    $clientvalue .= "," . number_format($final_perc_hedge[$i][$j], 2);
                    $l++;
                }
            }
        }
        // echo "\n".$consolidated_perc_hedge[$j];
        if($countclient > 1){
            $storeAll_IER_perc_hedge .=  "[" . "'" . $month[$j] . "'" . "," . number_format($consolidated_perc_hedge[$j], 2) . $clientvalue . "],";
        }
        else{
            $storeAll_IER_perc_hedge .=  "[" . "'" . $month[$j] . "'" . $clientvalue . "],";
        }
        // $storeAll_IER_perc_hedge .=  "[" . "'" . $month[$j] . "'" . "," . number_format($consolidated_perc_hedge[$j], 2) . $clientvalue . "],";
    }
} else {

    $k = 0;
    $quarter = ["Q1", "Q2", "Q3", "Q4"];
    foreach ($totalestimation as $key => $value) {
        // echo $key;
        for ($i = $key; $i == $key; $i++) {

            if ($k < 7) {
                // for ($i = 0; $i < count($clientName); $i++) {
                $strclient .= "," . "'" . $clientName[$i] . "'";   //client name
                $total_str .= "," . number_format($total_contract_perc_hedge[$i], 2);  // estimation of client

                // $totalestimation[$i] = $total_contract_est[$i];
                $k++;
            }
        }
    }
    if($countclient > 1){
        $storeAll_IER_Clients = "['','Avg'" . $strclient . "],";
        $storeAll_IER_Total = "['Total'," . number_format($total_perc_hedge, 2) . $total_str . "]";
    }
    else{
        $storeAll_IER_Clients = "[''" . $strclient . "],";
        $storeAll_IER_Total = "['Total'" . $total_str . "]";
    }
    // $storeAll_IER_Clients = "['','Avg'" . $strclient . "],";
    // $storeAll_IER_Total = "['Total'," . number_format($total_perc_hedge, 2) . $total_str . "]";
    // echo $storeAll_IER_Total;
    // echo $storeAll_IER_Clients;
    $storeAll_IER_perc_hedge = '';
    for ($j = 0; $j < 4; $j++) {
        $clientvalue = '';
        $strclient = '';
        $l = 0;
        foreach ($totalestimation as $key => $value) {
            for ($i = $key; $i == $key; $i++) {
                if ($l < 7) {
                    $clientvalue .= "," . number_format($final_perc_hedge_quarter[$i][$j], 2);
                    $l++;
                }
            }
        }
        // echo "\n".$clientvalue;
        if($countclient > 1){
            $storeAll_IER_perc_hedge .=  "[" . "'" . $quarter[$j] . "'" . "," . number_format($avg_perc_hedge_quarter[$j], 2) . $clientvalue . "],";

        }
        else{
            $storeAll_IER_perc_hedge .=  "[" . "'" . $quarter[$j] . "'" . $clientvalue . "],";

        }

        // $storeAll_IER_perc_hedge .=  "[" . "'" . $quarter[$j] . "'" . "," . number_format($avg_perc_hedge_quarter[$j], 2) . $clientvalue . "],";
    }
}
// echo $storeAll_IER_Clients."\n";
// echo $storeAll_IER_perc_hedge."\n";
// echo $storeAll_IER_Total;
?>


<script type="text/javascript">
    google.charts.load("current", {
        packages: ['corechart']
    });
    google.charts.setOnLoadCallback(drawChart);


    function drawChart() {
        var data = google.visualization.arrayToDataTable([
            <?php

            echo $storeAll_IER_Clients . $storeAll_IER_perc_hedge . $storeAll_IER_Total;

            ?>


        ]);

        var view = new google.visualization.DataView(data);


        var options = {

            title: "International Consumption Chart (% Hedged)",
            // isStacked:'percent',
            width: 1400,
            height: 400,
            backgroundColor: {
                fill: 'transparent'
            },
            //vertical = vAxis & horizontal = hAxis
            bar: {
                groupWidth: "80%"
            },
            legend: {
                position: "bottom"
            },
            // vAxis: {format:'#.# %'}, 
            vAxis: {
                gridlines: {
                    count: 10
                },
                ticks: [0, 20, 40, 60, 80, 100, 120],
                //     // format:'percent',
                // },
                //     vAxis: {
                // format: "#.#%",
                // // viewWindow: {
                // //    max:1.0,
                // //    min:0.2
                // // }
            }
            // vAxis: {format:'#.# %'}  //add number of grid line 
        };
        var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
        chart.draw(view, options);
    }
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js">
</script>
<script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
</script>