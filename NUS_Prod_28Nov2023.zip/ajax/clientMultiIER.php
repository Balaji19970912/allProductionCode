<?php
include '../dbconn.php';
session_start();
$strcountry = '';
$res = '';
if($_SESSION['role'] == 'Parent company' || $_SESSION['role'] == 'Client company') {
    $activeStatus = "AND state = 'Active'";
} else {
    $activeStatus = "";
}
if (isset($_POST['countries'])) {
    $valueReport = $_POST['valueReport'];
}
if (isset($_POST['countries'])) {
    $resCountry = $_POST["countries"];
    // echo $resCountry;
    foreach ($resCountry as $values) {
        $strcountry .= "'" . $values . "'" . ",";
    }
}
$trimCoun = trim($strcountry, ',');
if(empty($_SESSION['client'])) {
	// $getdatas = "SELECT * FROM clientcompanydata WHERE parentcompany='".$_POST['parentId']."' ".$activeStatus."
	// ORDER BY clientcompanydata.clientcompany ASC";
    $getdatas = "SELECT * FROM clientcompanydata WHERE  country IN ($trimCoun) 
    AND parentcompany = '".$_POST['parentId']."' ".$activeStatus."  AND state = 'Active' 
    ORDER BY clientcompany  ASC;";

} else {

	$inp = $_SESSION['client'];
	$arr = explode(" ", 	trim($inp));
	$arrLength = count($arr);
	$x='';
	for($i = 0 ;$i<$arrLength; $i++){
	  $x = $arr[$i].",".$x;
	}
	$res =  trim($x, ",");
	// $getdatas = "SELECT * FROM clientcompanydata WHERE id IN (".$res.") ".$activeStatus." ORDER BY clientcompanydata.clientcompany ASC;";
    $getdatas = "SELECT * FROM clientcompanydata WHERE  country IN ($trimCoun) 
    AND parentcompany = '".$_POST['parentId']."' ".$activeStatus."  AND state = 'Active' 
    ORDER BY clientcompany  ASC;";
}
// echo 'session client===>'.$_SESSION['client'];
// echo $getdatas;
$result = $conn->query($getdatas);

$selectAll = '<li><input type="checkbox"  onchange ="multiClients(this.value)" value="selectALL" id="selectAllClients" onclick="selectAllClient()"><label for="selectAllClients" id="labelSelectAll">Select All</label></li>';
$displayValue1 = '';
if ($valueReport == 'international') {
    // $sqlClient = "SELECT * FROM clientcompanydata WHERE  country IN ($trimCoun) AND parentcompany = '".$_POST['parentId']."' ".$activeStatus."  ORDER BY clientcompany  ASC;";
    $resClient = $conn->query($getdatas);
    $client = array();
    if ($resClient->num_rows > 0) {
        while ($rowClient = mysqli_fetch_assoc($resClient)) {
            $client[] = $rowClient;
        }
    }
    foreach ($client as $resClient) {
        $displayValue1 .= '<li><input type="checkbox" id="' . $resClient["id"] . '" class="clientCountry" value="' . $resClient["id"] . '" name="clientcheckboxIER[]"  onchange="multiClients(this.value)"><label for="' . $resClient["id"] . '">' . $resClient["clientcompany"] . ' - ' . $resClient["country"] . '</label></li>';
    }

    echo $selectAll.$displayValue1;
}


// cpr contract
// else {

//     if (isset($_POST['values1'])) {
//         $singleCountry = $_POST['values1'];
//     }
//     $sqlClient = "SELECT * FROM clientcompanydata WHERE parentcompany = '" . $_POST['parerntC'] . "' AND country= '" . $singleCountry . "';";
//     $resClient = $conn->query($sqlClient);
//     echo $sqlClient;
//     $client = array();
//     if ($resClient->num_rows > 0) {
//         while ($rowClient = mysqli_fetch_assoc($resClient)) {
//             $client[] = $rowClient;
//         }
//     }
//     $displayValue = "<option>Select Client</option>";
//     foreach ($client as $result) {
//         $displayValue .= '<option value="' . $result["id"] . '" >' . $result["clientcompany"] . '</option>';
//     }
//     echo $selectAllChkBox.$displayValue;
// }
