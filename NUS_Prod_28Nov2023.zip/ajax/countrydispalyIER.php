<?php
include '../dbconn.php';
session_start();

if($_SESSION['role'] == 'Parent company' || $_SESSION['role'] == 'Client company') {
    $activeStatus = "AND state = 'Active'";
} else {
    $activeStatus = "";
}

if(empty($_SESSION['client'])) {
	// $getdatas = "SELECT * FROM clientcompanydata WHERE parentcompany='".$_POST['parentId']."' ".$activeStatus."
	// ORDER BY clientcompanydata.clientcompany ASC";
    $getdatas = "SELECT DISTINCT country FROM clientcompanydata WHERE  parentcompany = '".$_POST['parentId']."' ".$activeStatus." AND clientcompanydata.state = 'Active'
    ORDER BY country ASC ;";

} else {
    // ECHO "1";
	$inp = $_SESSION['client'];
    // echo $inp;
	$arr = explode(" ", 	trim($inp));
	$arrLength = count($arr);
	$x='';
	for($i = 0 ;$i<$arrLength; $i++){
	  $x = $arr[$i].",".$x;
	}
	$res =  trim($x, ",");
	// echo $res;
	$getdatas = "SELECT * FROM clientcompanydata WHERE id IN (".$res.") ".$activeStatus." AND clientcompanydata.state = 'Active'
     ORDER BY clientcompanydata.clientcompany ASC;";
    // echo $getdatas;
}
// echo 'session client===>'.$_SESSION['client'];
// echo $getdatas;
// $result = $conn->query($getdatas);

if (isset($_POST['countries'])) {
    $valueReport = $_POST['valueReport'];
}


// $sqlCountry = "SELECT DISTINCT country FROM clientcompanydata WHERE  parentcompany = '".$_POST['parentId']."' ".$activeStatus."ORDER BY country ASC ;";
// echo $sqlCountry;
//get all countries under the selected company
$country=array();
$resCountry = $conn->query(	$getdatas );
if ($resCountry->num_rows > 0) {
    while($rowcountry = mysqli_fetch_assoc($resCountry)) {
    $country[] = $rowcountry;
    }
}
$displayValue = '<option>Select Country</option>';
$selectAll = '<li><input type="checkbox"  onchange ="multiCountries(this.value)"  id="selectAllChkbox" onclick="selectAllCountry()"><label for="selectAllChkbox" id="labelSelectAll" >Select All</label></li>';
$displayValue1 = '';
if(isset($_POST['valueReport'])){
    $valueReport =$_POST['valueReport'];
}
// $id=1;
if($valueReport == 'international'){
   foreach($country as $country) {
    $displayValue1 .='<li><input id="'.$country["country"].'" type="checkbox" id="value" class="countryD" value="'.$country["country"].'" name="multiselectIER[]"  onchange ="multiCountries(this.value)"><label for="'.$country["country"].'">'.$country["country"].'</label>
    </li>'; 
    // $id++;
   } 
   
   echo $selectAll.$displayValue1;
  
}



// else{
//     // echo "<script>alert('$valueReport')</script>";
    
//     foreach($country as $country){
  
//         $displayValue .='<option value="'.$country["country"].'">'.$country["country"].'</option>';   //displaying in select box
//     }
//     echo $displayValue;
// }
