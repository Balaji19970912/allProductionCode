<?php
include '../dbconn.php';
session_start();
if($_SESSION['role'] == 'Parent company' || $_SESSION['role'] == 'Client company') {
    $activeStatus = "AND state = 'Active'";
} else {

    $activeStatus = "";
}
if(empty($_SESSION['client'])) {
    $getdatas = "SELECT DISTINCT country FROM clientcompanydata WHERE  parentcompany = '".$_POST['parentID']."' ".$activeStatus." AND clientcompanydata.state = 'Active'
    ORDER BY country ASC ;";
    // echo $getdatas;
}
else{
    $getdatas = "SELECT DISTINCT country FROM clientcompanydata WHERE  parentcompany = '".$_POST['parentID']."' ".$activeStatus." AND clientcompanydata.state = 'Active'
    ORDER BY country ASC ;";
    // echo $getdatas;
}
$country=array();
$displayValue = '<option value="">Select Country</option>';
$resCountry = $conn->query(	$getdatas );
if ($resCountry->num_rows > 0) {
    while($rowcountry = mysqli_fetch_assoc($resCountry)) {
    $country[] = $rowcountry;
    }
}

    foreach($country as $country){
  
        $displayValue .='<option value="'.$country["country"].'">'.$country["country"].'</option>';   //displaying in select box
    }
    echo $displayValue;
