<?php
include "../dbconn.php";
session_start();
$valueReport = '';
if ($_SESSION['role'] == 'Parent company' || $_SESSION['role'] == 'Client company') {
    // $activeStatus = "AND state = 'Active'";
    $activeStatus = "AND nus_supply_contract.state = 'Active'";
} else {
    $activeStatus = "";
}
// check client values
$strclientID = '';
if (isset($_POST['clientID'])) {
    $resClient = $_POST["clientID"];
    foreach ($resClient as $values) {
        $strclientID .= $values . ",";
    }
}
$trimCoun = trim($strclientID, ',');
if ($trimCoun == '') {
    $trimCoun = 0;
}
$valueReport = 'international';

if (empty($_SESSION['client'])) {
    $getdatas = "SELECT * FROM nus_supply_contract 
    INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId 
    WHERE clientId IN ($trimCoun) AND commodityName = '" . $_POST['commodity'] . "' " . $activeStatus . " AND nus_supply_contract.state = 'Active'
    ORDER BY nus_supply_contract.contract_id ASC;";
} else {
    // echo "session====>" .$_SESSION['client'];
    // echo "parent and client company";
    // $inp = $_SESSION['clientID'];
    // $arr = explode(" ",     trim($inp));
    // $arrLength = count($arr);
    // $x = '';
    // for ($i = 0; $i < $arrLength; $i++) {
    //     $x = $arr[$i] . "," . $x;
    // }
    // $res =  trim($x, ",");
    // echo $res;

    $getdatas = "SELECT * FROM nus_supply_contract
     INNER JOIN clientcompanydata ON clientcompanydata.id = nus_supply_contract.clientId 
    WHERE clientId IN ($trimCoun) AND commodityName = '" . $_POST['commodity'] . "' " . $activeStatus . " AND nus_supply_contract.state = 'Active'
    ORDER BY nus_supply_contract.contract_id ASC;";
  
}
// echo $getdatas;

$result = $conn->query($getdatas);  

// select ALL code
$selectAll = '<li><input type="checkbox" onchange=contractsyear(this.value) value="selectALL" id="selectAllContracts" onclick="selectAllContract()"><label for="selectAllContracts" id="labelSelectAll">Select All</label></li>';
if ($valueReport == 'international') {
    $result5 = mysqli_query($conn, $getdatas);
    $contracts = array();
    $contractsDisplay = '';
    if ($result5->num_rows > 0) {
        while ($rowContracts = mysqli_fetch_assoc($result5)) {
            $contracts[] = $rowContracts;
        }
    }
    foreach ($contracts as $rowContracts) {
        $startDate = date_create($rowContracts['contractTermfromDate']);
        $startDate =  date_format($startDate, "d-M-Y");
        $contractsDisplay .= '<li><input type="checkbox" id="supplier' . $rowContracts["supplierId"] . '"  class="contractscheckbox" value="' . $rowContracts["supplierId"] . '" name="contractcheckboxIER[]"  onclick=contractsyear(this.value) ><label for="supplier' . $rowContracts["supplierId"] . '">' . $rowContracts["clientcompany"] . ' - ' . $rowContracts["contract_id"] . ' - ' . $rowContracts["countryName"] . ' - ' . $startDate . '</label></li>';
    }

    echo $selectAll . $contractsDisplay;
}

// else{
// // echo $_POST['commodity'];
  
//   $sqlQuery5 = "SELECT * FROM nus_supply_contract WHERE parentId = '".$_POST['parent']."'
//   AND countryName='".$_POST['country']."' 
//   AND clientId = '".$_POST['clientId']."' 
//   AND commodityName = '".$_POST['commodity']."'
//   AND contractType ='indexed';";
//   $result5 = mysqli_query($conn, $sqlQuery5);
//   // $id= 1;

// $contracts = array();
// $contractsDisplay ='';
// if($result5->num_rows > 0){
//     while($rowContracts = mysqli_fetch_assoc($result5)){
//         $contracts[] = $rowContracts;
//     }
// }
// foreach($contracts as $rowContracts) {
//     $contractsDisplay .='<li><input type="checkbox"  class="contractscheckbox" id="'.$rowContracts["supplierId"].'" value="'.$rowContracts["supplierId"].'" name="contractcheckbox[]"  onclick=contractsyear(this.value) ><label for="'.$rowContracts["supplierId"].'">'.$rowContracts["contract_id"].'</label></li>'; 
//    } 
   
//    echo $contractsDisplay;
 
// }
