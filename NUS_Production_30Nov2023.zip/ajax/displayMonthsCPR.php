<?php
include "../dbconn.php";
// echo "<script>alert('12344');</script>";
$displayMon = '';
$search_year = $_POST['year'];
$contractsID = $_POST['contractID'];
$viewValue = $_POST['viewValue'];
// echo $search_year;
$sqlQueryMon = "SELECT * FROM nus_supply_contract WHERE supplierId IN ($contractsID) ;";
//  $sqlQueryMon = "SELECT * FROM nus_supply_contract INNER JOIN nus_calenderyear 
//  ON nus_supply_contract.supplierId =nus_calenderyear.supplierid
//  WHERE calenderyear = $year AND nus_supply_contract.supplierid IN ($contractsID);"; 
// echo $sqlQueryMon;
$resultMon = mysqli_query($conn, $sqlQueryMon);
$year = [];
$array_dates = [];
$displayMonname = '';
$displayMontext = '';
$month_num=[];
$res=[];

$months = [
  'Jan' => '1',
  'Feb' => '2',
  'Mar' => '3',
  'Apr' => '4',
  'May' => '5',
  'Jun' => '6',
  'July' => '7',
  'Aug' => '8',
  'Sept' => '9',
  'Oct' => '10',
  'Nov' => '11',
  'Dec' => '12'
];
// $months = ['1'=>'Jan',
// '2'=>'Feb',
// '3'=>'Mar',
// '4'=>'Apr',
// '5'=>'Jun',
// '6'=>'July',
// '7'=>'Aug',
// '8'=>'Sept',
// '9' =>'Oct',
// '10' =>'Nov',
// '11' =>'Dec'];
$i = 0;
if($viewValue == 'Monthly'){

// echo "yes"  ;
while ($yearMonRow = mysqli_fetch_assoc($resultMon)) {
  $year[$i] = $yearMonRow['allmonts'];
  $array_dates[] = explode(',', $year[$i]);
  $i++;
}
// echo "<pre>";
// print_r(   $year);

// echo "<pre>";
// print_r($array_dates);
// print_r(count($array_dates));
// echo gettype($array_dates);
$explode = [];
$store_year_dates = [];
// loop to search particular year month date and year
for($i=0;$i<count($array_dates);$i++){
  for($j=0;$j<count($array_dates[$i]);$j++){
    if(strpos($array_dates[$i][$j] ,$search_year) !== false){
// echo "true";
  $store_year_dates[]=$array_dates[$i][$j];
    }
  } 
}
// echo "<pre>";
// print_r($store_year_dates);



for ($j = 0; $j < count($store_year_dates); $j++) {
  $explode[$j] = explode('-', $store_year_dates[$j]);
  $month_num[] = $explode[$j][1];
}
// print_r($month_num);
$unique_month_num = array_unique($month_num);
// echo "<pre>";
sort($unique_month_num);

for ($k = 0; $k < count($unique_month_num); $k++) {
  $res[] = array_search($unique_month_num[$k], $months);
}

// sort($res);
// print_r($res);
$monthnames =  implode(',',$res);
$monthall = '<input type="hidden" name="allselectedmonths" value="'.$monthnames .'">';
$i = 0;
foreach ($res as $monthName) {
  $displayMonname .= '<p >' . $monthName . '</p>';
  $displayMontext .= '<div ><input type="text" name=unhedgeValues[] class="unhedgeInput" placeholder="0.00" onkeyup="unhedgeEffec(' . $i . ')" name="hedgevalmon[]" id="hedgevalmon' . $i . '"></div>';
  $i++;
}

$displayMon .= '<div class="monthName">' . $displayMonname . '</div> <div class="inputText">' . $displayMontext . '</div>';

// $displayMon .= '<div class="monUnhedge_CPR">
// <div class="box1" id="monthNameDisplay">

// ' . $displayMonname . '
// </div>
// <div class="box1" id="inputValueUnhedge">
// ' . $displayMontext . '</div>
// </div>';



// $displayMon .=" <table class='table1'>
// <thead>
//   <th>Month</th>
//   <th>Unhedged Effective Price</th>
// </thead>
// <tbody>
//   <tr>
//     <td></td>
//     <td></td>
//   </tr>
// </tbody>
// </table>
// <div><p>Hello</p></div>
// ";

echo $monthall.$displayMon;
}
