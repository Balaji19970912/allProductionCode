<?php
include '../dbconn.php';
if($_SESSION['role'] == 'Parent company' || $_SESSION['role'] == 'Client company') {
    $activeStatus = "AND state = 'Active'";
} else {
    $activeStatus = "";
}
if(empty($_SESSION['client'])) {
	// $getdatas = "SELECT * FROM clientcompanydata WHERE parentcompany='".$_POST['parentId']."' ".$activeStatus."
	// ORDER BY clientcompanydata.clientcompany ASC";
    $getdatas = "SELECT DISTINCT country FROM clientcompanydata WHERE  parentcompany = '".$_POST['parentId']."' ".$activeStatus." AND clientcompanydata.state = 'Active'
    ORDER BY country ASC ;";
}
else{
    $getdatas = "SELECT DISTINCT country FROM clientcompanydata WHERE  parentcompany = '".$_POST['parentId']."' ".$activeStatus." AND clientcompanydata.state = 'Active'
    ORDER BY country ASC ;";
}
$country=array();
$resCountry = $conn->query(	$getdatas );
if ($resCountry->num_rows > 0) {
    while($rowcountry = mysqli_fetch_assoc($resCountry)) {
    $country[] = $rowcountry;
    }
}

    foreach($country as $country){
  
        $displayValue .='<option value="'.$country["country"].'">'.$country["country"].'</option>';   //displaying in select box
    }
    echo $displayValue;


?>